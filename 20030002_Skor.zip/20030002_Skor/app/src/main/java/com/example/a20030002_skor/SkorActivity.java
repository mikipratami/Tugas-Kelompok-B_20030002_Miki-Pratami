package com.example.a20030002_skor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SkorActivity extends AppCompatActivity {

    public static String NAMA_TIM_A = "NAMA_TIM_A";
    public static String NAMA_TIM_B = "NAMA_TIM_B";

    String getNamaTimA;
    String getNamaTimB;

    TextView text_point_a, text_point_b, angka_a, angka_b;
    Button button_point_satu_a, button_point_dua_a, button_point_tiga_a;
    Button button_point_satu_b, button_point_dua_b, button_point_tiga_b;
    Button button_reset_point_a, button_reset_point_b;

    int point_a, point_b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skor);

        getNamaTimA = getIntent().getExtras().getString(NAMA_TIM_A);
        getNamaTimB = getIntent().getExtras().getString(NAMA_TIM_B);

        text_point_a = findViewById(R.id.textPointA);
        text_point_b = findViewById(R.id.textPointB);
        angka_a = findViewById(R.id.angkaA);
        angka_b = findViewById(R.id.angkaB);
        button_point_satu_a = findViewById(R.id.btnSatuA);
        button_point_dua_a = findViewById(R.id.btnDuaA);
        button_point_tiga_a = findViewById(R.id.btnTigaA);
        button_point_satu_b = findViewById(R.id.btnSatuB);
        button_point_dua_b = findViewById(R.id.btnDuaB);
        button_point_tiga_b = findViewById(R.id.btnTigaB);
        button_reset_point_a = findViewById(R.id.resetA);
        button_reset_point_b = findViewById(R.id.resetB);

        text_point_a.setText(getNamaTimA);
        text_point_b.setText(getNamaTimB);

        button_point_satu_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_a++;
                angka_a.setText(String.valueOf(point_a));
            }
        });

        button_point_dua_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_a+=2;
                angka_a.setText(String.valueOf(point_a));
            }
        });

        button_point_tiga_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_a+=3;
                angka_a.setText(String.valueOf(point_a));
            }
        });

        button_point_satu_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_b++;
                angka_b.setText(String.valueOf(point_b));
            }
        });

        button_point_dua_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_b+=2;
                angka_b.setText(String.valueOf(point_b));
            }
        });

        button_point_tiga_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_b+=3;
                angka_b.setText(String.valueOf(point_b));
            }
        });

        button_reset_point_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_a = 0;
                angka_a.setText(String.valueOf(point_a));
            }
        });

        button_reset_point_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                point_b = 0;
                angka_b.setText(String.valueOf(point_b));
            }
        });
    }
}