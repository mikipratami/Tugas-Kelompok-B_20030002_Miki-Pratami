package com.example.a20030002_skor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edit_tim_a, edit_tim_b;
    Button btn_input;

    String nama_tim_a, nama_tim_b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_tim_a = findViewById(R.id.editTimA);
        edit_tim_b = findViewById(R.id.editTimB);
        btn_input = findViewById(R.id.btnInput);

        btn_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nama_tim_a = edit_tim_a.getText().toString();
                nama_tim_b = edit_tim_b.getText().toString();
                Log.e("TIM A", nama_tim_a);
                Log.e("TIM B", nama_tim_b);
                Intent intent = new Intent(MainActivity.this, SkorActivity.class);
                intent.putExtra(SkorActivity.NAMA_TIM_A, nama_tim_a);
                intent.putExtra(SkorActivity.NAMA_TIM_B, nama_tim_b);
                startActivity(intent);
            }
        });
    }
}